from django.apps import AppConfig


class IhamLoginadminConfig(AppConfig):
    name = 'IHAM_loginAdmin'
