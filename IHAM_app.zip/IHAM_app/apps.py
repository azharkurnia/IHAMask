from django.apps import AppConfig


class IhamAppConfig(AppConfig):
    name = 'IHAM_app'
