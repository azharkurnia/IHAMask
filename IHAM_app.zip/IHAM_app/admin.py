from django.contrib import admin
from .models import upcomingEvents, FAQ
# Register your models here.
admin.site.register(upcomingEvents)
admin.site.register(FAQ)